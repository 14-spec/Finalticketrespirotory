/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller.datastructures;

/**
 *
 * @author DELL
 */
import attendeemodel.attendeemodel;
import java.util.Arrays;
public class Queue {int startCount = -1;
    int endCount = -1;

    attendeemodel[] tickets = new attendeemodel[4];

    public int getQueueSize() {
        return tickets.length;
    }

    public void enqueue(attendeemodel ticket) {
        if (isFull()) {
            System.out.println("Queue is Full");
        } else {
            if (startCount == -1) {
                startCount++;
            }
            tickets[++endCount] = ticket;
            System.out.println(ticket + " data is added");
        }
    }

    public void dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is Empty!");
        } else {
            System.out.println(tickets[startCount] + " Data is removed!");
            tickets[startCount++] = null;
            if (startCount > endCount) {
                startCount = -1;
                endCount = -1;
            }
        }
    }

    public boolean isEmpty() {
        return startCount == -1 && endCount == -1;
    }

    public boolean isFull() {
        return endCount == getQueueSize() - 1;
    }

    public void displayQueue() {
        System.out.println(Arrays.toString(tickets));
    }
    
}
