/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package attendeemodel;

/**
 *
 * @author DELL
 */
public class attendeemodel {  
    private  int ticketid;
    private String attendeename;
    private String emailaddress;
    private int ticketprice;
    private String paymentstatus;  
    
    public attendeemodel(){}
    
    public attendeemodel(int ticketid, String attendeename,String emailaddress,int ticketprice,String paymentstatus){
        this.ticketid = ticketid;
        this.attendeename=attendeename;
        this.emailaddress=emailaddress;
        this.ticketprice= ticketprice;
        this.paymentstatus=paymentstatus;
        
    }  
    public int getticketid(){
        return ticketid; 
    }
    
    public void setticketid(int ticketid){
        this.ticketid = ticketid;
    }    
    
    public String getattendeename(){
        return attendeename;
    }

    public void setattendeename(String attendeename){
        this.attendeename = attendeename;
    }
    
    public String getemailaddress(){
        return emailaddress;
    }  
    
    public void setemailaddress(String emailaddress){
        this.emailaddress = emailaddress;
    }  
    
   public int getticketprice(){
      return  ticketprice;
   } 
   
   public void setticketprice(int ticketprice){
       this.ticketprice = ticketprice;
   }  
   
   public String getpaymentstatus(){
        return paymentstatus;
   } 
   public void setpaymentstatus(String paymentstatus){
       this.paymentstatus = paymentstatus;
   } 
   
    @Override
    public String toString() {
        String ticketId = null;
        String attendeeName = null;
        String ticketPrice = null;
        String emailAddress = null;
        String paymentStatus = null;
        return "Ticket{" +
                "ticketId=" + ticketId +
                ", attendeeName='" + attendeeName + '\'' +
                ", emailAddress='" + emailAddress + '\'' +
                ", ticketPrice=" + ticketPrice +
                ", paymentStatus='" + paymentStatus + '\'' +
                '}';
    }
}
